export const questions=[
    {
        questionText:"How many days are there in a week?",
        answerOptions:[
            {answerText:"2",isCorrect:false},
            {answerText:"9",isCorrect:false},
            {answerText:"7",isCorrect:true},
            {answerText:"5",isCorrect:false},
        ],
    },
    {
        questionText:"Who is CEO of Tesla?",
        answerOptions:[
            {answerText:"MERK",isCorrect:false},
            {answerText:"anc",isCorrect:false},
            {answerText:"Elon Mask",isCorrect:true},
            {answerText:"Junaid",isCorrect:false},
        ],
    },
    {
        questionText:"HTML stands for?",
        answerOptions:[
            {answerText:"Structuring Hyper Language",isCorrect:false},
            {answerText:"Object Oriented HTML",isCorrect:false},
            {answerText:"Progming for WEB",isCorrect:false},
            {answerText:"Hyper Text Markup Language",isCorrect:true},
        ],
    },
]