import logo from './logo.svg';
import './App.css';
import Quizz from './Quizz';

function App() {
  return (
    <div className="App">
     <h1>React Quiz App</h1>
     <div>
      <Quizz/>
     </div>
    </div>
  );
}

export default App;
